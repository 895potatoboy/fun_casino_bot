import sqlite3
import os
from pathlib import Path

DB_PATH = os.environ.get("DB_PATH", "casino.db")

class Database:
    def __init__(self):
        self.conn = sqlite3.connect(DB_PATH, check_same_thread=False)
        self._create_tables()

    def _create_tables(self):
        self.conn.executescript("""
            CREATE TABLE IF NOT EXISTS users (
                user_id   INTEGER PRIMARY KEY,
                name      TEXT    NOT NULL,
                balance   INTEGER NOT NULL DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS transactions (
                id        INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id   INTEGER NOT NULL,
                type      TEXT    NOT NULL,   -- 'deposit' | 'win' | 'loss' | 'push'
                amount    INTEGER NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );
        """)
        self.conn.commit()

    def ensure_user(self, user_id: int, name: str):
        self.conn.execute(
            "INSERT OR IGNORE INTO users (user_id, name) VALUES (?, ?)",
            (user_id, name),
        )
        self.conn.commit()

    def get_balance(self, user_id: int) -> int:
        row = self.conn.execute(
            "SELECT balance FROM users WHERE user_id = ?", (user_id,)
        ).fetchone()
        return row[0] if row else 0

    def add_tokens(self, user_id: int, amount: int):
        self.conn.execute(
            "UPDATE users SET balance = balance + ? WHERE user_id = ?",
            (amount, user_id),
        )
        self.conn.execute(
            "INSERT INTO transactions (user_id, type, amount) VALUES (?, 'deposit', ?)",
            (user_id, amount),
        )
        self.conn.commit()

    def update_balance(self, user_id: int, delta: int):
        """Apply win/loss delta (can be negative). Balance floor = 0."""
        self.conn.execute(
            "UPDATE users SET balance = MAX(0, balance + ?) WHERE user_id = ?",
            (delta, user_id),
        )
        t = "win" if delta > 0 else ("loss" if delta < 0 else "push")
        self.conn.execute(
            "INSERT INTO transactions (user_id, type, amount) VALUES (?, ?, ?)",
            (user_id, t, abs(delta)),
        )
        self.conn.commit()

    def leaderboard(self, limit: int = 10):
        rows = self.conn.execute(
            "SELECT name, balance FROM users ORDER BY balance DESC LIMIT ?", (limit,)
        ).fetchall()
        return rows
