import os
import logging
import random
import asyncio
from telegram import (
    Update, InlineKeyboardButton, InlineKeyboardMarkup,
    LabeledPrice
)
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    PreCheckoutQueryHandler, MessageHandler, filters,
    ContextTypes
)
from database import Database

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

db = Database()

# ── Config ──────────────────────────────────────────────────────────────────
BOT_TOKEN   = os.environ["BOT_TOKEN"]
STARS_TO_TOKENS = 10          # 1 Star  → 10 fun-tokens
MIN_STARS        = 1
MAX_STARS        = 250

# ── Helpers ──────────────────────────────────────────────────────────────────
def balance_text(user_id: int) -> str:
    bal = db.get_balance(user_id)
    return f"🎰 Your balance: *{bal:,} fun-tokens* (not redeemable)"

def main_menu(user_id: int) -> InlineKeyboardMarkup:
    bal = db.get_balance(user_id)
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("💸 Deposit Stars",       callback_data="deposit_menu")],
        [
            InlineKeyboardButton("🎲 Dice",             callback_data="game_dice"),
            InlineKeyboardButton("🪙 Coin Flip",        callback_data="game_coin"),
        ],
        [
            InlineKeyboardButton("🎰 Slots",            callback_data="game_slots"),
            InlineKeyboardButton("🃏 Blackjack",        callback_data="game_bj"),
        ],
        [InlineKeyboardButton(f"💰 Balance: {bal:,}",  callback_data="balance")],
    ])

# ── Commands ──────────────────────────────────────────────────────────────────
async def start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    db.ensure_user(user.id, user.first_name)
    await update.message.reply_text(
        f"👋 Welcome to *Lucky Stars Casino*, {user.first_name}!\n\n"
        "💫 Deposit Telegram Stars to get fun-tokens.\n"
        "🎰 Use tokens to play games — they can't be withdrawn.\n\n"
        "Choose an option below:",
        parse_mode="Markdown",
        reply_markup=main_menu(user.id),
    )

async def help_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "*Lucky Stars Casino — Help*\n\n"
        "/start  — Open main menu\n"
        "/balance — Check your fun-token balance\n"
        "/deposit — Deposit Telegram Stars\n"
        "/leaderboard — Top 10 richest players\n\n"
        "⚠️ *Fun-tokens have zero real-world value and cannot be withdrawn.*",
        parse_mode="Markdown",
    )

async def balance_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    db.ensure_user(update.effective_user.id, update.effective_user.first_name)
    await update.message.reply_text(
        balance_text(update.effective_user.id),
        parse_mode="Markdown",
        reply_markup=main_menu(update.effective_user.id),
    )

async def leaderboard_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    rows = db.leaderboard()
    lines = ["🏆 *Top 10 Richest Players*\n"]
    medals = ["🥇","🥈","🥉"] + ["  "] * 7
    for i, (name, bal) in enumerate(rows):
        lines.append(f"{medals[i]} {name}: *{bal:,}* tokens")
    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")

# ── Deposit Flow ─────────────────────────────────────────────────────────────
DEPOSIT_AMOUNTS = [1, 5, 10, 50, 100]

async def deposit_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    db.ensure_user(update.effective_user.id, update.effective_user.first_name)
    await _send_deposit_menu(update.message.reply_text)

async def _send_deposit_menu(send_fn):
    buttons = [
        [InlineKeyboardButton(
            f"⭐ {s} Star{'s' if s>1 else ''} → {s*STARS_TO_TOKENS:,} tokens",
            callback_data=f"buy_{s}"
        )] for s in DEPOSIT_AMOUNTS
    ]
    buttons.append([InlineKeyboardButton("🔙 Back", callback_data="main_menu")])
    await send_fn(
        "💸 *Choose how many Stars to deposit:*\n\n"
        f"Rate: 1 ⭐ = {STARS_TO_TOKENS} fun-tokens\n"
        "_(Stars are non-refundable once converted)_",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup(buttons),
    )

async def pre_checkout(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await update.pre_checkout_query.answer(ok=True)

async def successful_payment(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    user    = update.effective_user
    payment = update.message.successful_payment
    stars   = payment.total_amount          # already in Stars (integer)
    tokens  = stars * STARS_TO_TOKENS
    db.ensure_user(user.id, user.first_name)
    db.add_tokens(user.id, tokens)
    new_bal = db.get_balance(user.id)
    await update.message.reply_text(
        f"✅ Deposited *{stars} Star{'s' if stars>1 else ''}* → *+{tokens:,} fun-tokens*!\n"
        f"New balance: *{new_bal:,} tokens*",
        parse_mode="Markdown",
        reply_markup=main_menu(user.id),
    )

# ── Callback Router ──────────────────────────────────────────────────────────
async def button(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q    = update.callback_query
    data = q.data
    uid  = q.from_user.id
    db.ensure_user(uid, q.from_user.first_name)
    await q.answer()

    if data == "main_menu":
        await q.edit_message_text(
            "🎰 *Lucky Stars Casino* — Main Menu",
            parse_mode="Markdown",
            reply_markup=main_menu(uid),
        )

    elif data == "balance":
        await q.edit_message_text(
            balance_text(uid),
            parse_mode="Markdown",
            reply_markup=main_menu(uid),
        )

    elif data == "deposit_menu":
        await q.edit_message_text(
            "💸 *Choose how many Stars to deposit:*\n\n"
            f"Rate: 1 ⭐ = {STARS_TO_TOKENS} fun-tokens\n"
            "_(Stars are non-refundable once converted)_",
            parse_mode="Markdown",
            reply_markup=_deposit_keyboard(),
        )

    elif data.startswith("buy_"):
        stars = int(data.split("_")[1])
        await ctx.bot.send_invoice(
            chat_id=uid,
            title=f"{stars} Star{'s' if stars>1 else ''} → {stars*STARS_TO_TOKENS:,} Fun-Tokens",
            description="Fun-tokens are for casino games only — no real value, non-withdrawable.",
            payload=f"stars_{stars}",
            currency="XTR",          # Telegram Stars currency code
            prices=[LabeledPrice(label="Fun-Tokens", amount=stars)],
        )

    elif data.startswith("game_"):
        game = data.split("_")[1]
        await _show_bet_menu(q, uid, game)

    elif data.startswith("bet_"):
        _, game, amount_str = data.split("_")
        await _play_game(q, uid, game, int(amount_str))

def _deposit_keyboard():
    buttons = [
        [InlineKeyboardButton(
            f"⭐ {s} Star{'s' if s>1 else ''} → {s*STARS_TO_TOKENS:,} tokens",
            callback_data=f"buy_{s}"
        )] for s in DEPOSIT_AMOUNTS
    ]
    buttons.append([InlineKeyboardButton("🔙 Back", callback_data="main_menu")])
    return InlineKeyboardMarkup(buttons)

# ── Bet menu ─────────────────────────────────────────────────────────────────
GAME_NAMES = {"dice": "🎲 Dice", "coin": "🪙 Coin Flip",
              "slots": "🎰 Slots", "bj": "🃏 Blackjack"}
BET_SIZES  = [10, 25, 50, 100, 250, 500]

async def _show_bet_menu(q, uid: int, game: str):
    bal = db.get_balance(uid)
    buttons = []
    row = []
    for b in BET_SIZES:
        label = f"{b:,}" if bal >= b else f"🚫{b:,}"
        row.append(InlineKeyboardButton(label, callback_data=f"bet_{game}_{b}"))
        if len(row) == 3:
            buttons.append(row); row = []
    if row: buttons.append(row)
    buttons.append([InlineKeyboardButton("🔙 Back", callback_data="main_menu")])
    await q.edit_message_text(
        f"{GAME_NAMES[game]}\n\n"
        f"Balance: *{bal:,}* tokens\n"
        "Choose your bet:",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup(buttons),
    )

# ── Games ────────────────────────────────────────────────────────────────────
async def _play_game(q, uid: int, game: str, bet: int):
    bal = db.get_balance(uid)
    if bal < bet:
        await q.edit_message_text(
            f"❌ Not enough tokens!\nYou have *{bal:,}* but bet is *{bet:,}*.",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("💸 Deposit Stars", callback_data="deposit_menu")],
                [InlineKeyboardButton("🔙 Back", callback_data="main_menu")],
            ]),
        )
        return

    if game == "dice":   result, delta, detail = _dice(bet)
    elif game == "coin": result, delta, detail = _coin(bet)
    elif game == "slots": result, delta, detail = _slots(bet)
    elif game == "bj":   result, delta, detail = _blackjack(bet)
    else:
        await q.edit_message_text("Unknown game."); return

    db.update_balance(uid, delta)
    new_bal = db.get_balance(uid)
    outcome = "🎉 *WIN!*" if delta > 0 else ("💔 *LOSS*" if delta < 0 else "🤝 *PUSH*")

    await q.edit_message_text(
        f"{GAME_NAMES[game]}\n\n"
        f"{detail}\n\n"
        f"{outcome}  {'+' if delta>=0 else ''}{delta:,} tokens\n"
        f"Balance: *{new_bal:,}* tokens",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🔄 Play Again", callback_data=f"game_{game}")],
            [InlineKeyboardButton("🏠 Main Menu", callback_data="main_menu")],
        ]),
    )

# ── Game logic ────────────────────────────────────────────────────────────────
def _dice(bet: int):
    """Roll two dice. Sum 7 or 11 wins 1×; sum 2,3,12 loses; else push."""
    d1, d2 = random.randint(1,6), random.randint(1,6)
    s = d1 + d2
    FACES = ["⚀","⚁","⚂","⚃","⚄","⚅"]
    detail = f"{FACES[d1-1]} + {FACES[d2-1]} = *{s}*"
    if s in (7, 11):  return "win",  bet,  detail + "\nNatural win! 🎉"
    if s in (2, 3, 12): return "loss", -bet, detail + "\nCraps! 💀"
    return "push", 0, detail + "\nPush — no change."

def _coin(bet: int):
    side = random.choice(["Heads 🪙", "Tails 🔵"])
    win  = random.random() < 0.5
    detail = f"Coin landed: *{side}*\nYou called: *{'Heads 🪙' if win else 'Tails 🔵'}*"
    return ("win", bet, detail) if win else ("loss", -bet, detail)

SLOT_REELS = ["🍒","🍋","🔔","⭐","💎","7️⃣","🍀"]
SLOT_PAYS  = {
    "💎": 20, "7️⃣": 15, "⭐": 10,
    "🍀": 8, "🔔": 5, "🍋": 3, "🍒": 2,
}
def _slots(bet: int):
    reels = [random.choice(SLOT_REELS) for _ in range(3)]
    line  = " | ".join(reels)
    if reels[0] == reels[1] == reels[2]:
        mult = SLOT_PAYS[reels[0]]
        return "win", bet * mult, f"[ {line} ]\nJACKPOT × {mult}! 🎰"
    if reels[0] == reels[1] or reels[1] == reels[2]:
        return "win", bet, f"[ {line} ]\nTwo of a kind — 1× win!"
    return "loss", -bet, f"[ {line} ]\nNo match."

def _card():
    rank = random.choice(["A","2","3","4","5","6","7","8","9","10","J","Q","K"])
    suit = random.choice(["♠","♥","♦","♣"])
    val  = 11 if rank == "A" else (10 if rank in ("J","Q","K") else int(rank))
    return rank+suit, val

def _hand_value(hand):
    total = sum(v for _,v in hand)
    aces  = sum(1 for r,_ in hand if r.startswith("A"))
    while total > 21 and aces:
        total -= 10; aces -= 1
    return total

def _blackjack(bet: int):
    player = [_card(), _card()]
    dealer = [_card(), _card()]
    # Simple: player stands on 17+; dealer hits on <17
    while _hand_value(player) < 17:
        player.append(_card())
    while _hand_value(dealer) < 17:
        dealer.append(_card())
    pv, dv = _hand_value(player), _hand_value(dealer)
    ph = " ".join(c for c,_ in player)
    dh = " ".join(c for c,_ in dealer)
    detail = f"You: {ph} = *{pv}*\nDealer: {dh} = *{dv}*"
    if pv > 21:    return "loss", -bet, detail + "\nBust! 💥"
    if dv > 21:    return "win",  bet,  detail + "\nDealer busts! 🎉"
    if pv > dv:    return "win",  bet,  detail
    if pv < dv:    return "loss", -bet, detail
    return "push", 0, detail + "\nPush!"

# ── Main ──────────────────────────────────────────────────────────────────────
def main():
    app = Application.builder().token(BOT_TOKEN).build()

    app.add_handler(CommandHandler("start",        start))
    app.add_handler(CommandHandler("help",         help_cmd))
    app.add_handler(CommandHandler("balance",      balance_cmd))
    app.add_handler(CommandHandler("deposit",      deposit_cmd))
    app.add_handler(CommandHandler("leaderboard",  leaderboard_cmd))
    app.add_handler(CallbackQueryHandler(button))
    app.add_handler(PreCheckoutQueryHandler(pre_checkout))
    app.add_handler(MessageHandler(filters.SUCCESSFUL_PAYMENT, successful_payment))

    logger.info("Bot is running…")
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
