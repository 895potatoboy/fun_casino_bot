# 🎰 Lucky Stars Casino Bot

A Telegram casino bot where users deposit **Telegram Stars** to receive **fun-tokens** that can only be used for gambling — never withdrawn.

## Features

| Game | Rules |
|------|-------|
| 🎲 Dice | Roll 2 dice — 7/11 wins, 2/3/12 loses, else push |
| 🪙 Coin Flip | 50/50 — double or nothing |
| 🎰 Slots | 3 reels — match all 3 for up to 20× jackpot |
| 🃏 Blackjack | Auto-stand at 17; beat the dealer |

- `/start` — Main menu  
- `/balance` — Check fun-token balance  
- `/deposit` — Buy fun-tokens with Telegram Stars  
- `/leaderboard` — Top 10 richest players  

---

## Setup (5 minutes)

### 1. Create a bot
1. Message [@BotFather](https://t.me/BotFather) on Telegram
2. `/newbot` → follow prompts → copy the **HTTP API token**
3. Enable Stars payments:  
   `/mybots` → your bot → **Payments** → **Telegram Stars** → enable

### 2. Clone and configure
```bash
git clone <your-repo>
cd casino-bot
cp .env.example .env
# Edit .env and paste your BOT_TOKEN
```

### 3. Run locally
```bash
pip install -r requirements.txt
python bot.py
```

---

## Free Cloud Hosting

### Option A — Railway (recommended, easiest)
1. Push to GitHub
2. Go to [railway.app](https://railway.app) → **New Project** → **Deploy from GitHub**
3. Add env variable: `BOT_TOKEN = <your token>`
4. Railway auto-detects the Dockerfile and deploys  
5. Add a **Volume** mounted at `/data` for the SQLite DB to persist

Free tier: 500 hours/month (enough for a hobby bot).

### Option B — Render
1. Push to GitHub
2. Go to [render.com](https://render.com) → **New** → **Background Worker**
3. Connect your repo; Render auto-detects `render.yaml`
4. Add env var `BOT_TOKEN` in the dashboard
5. Deploy

Free tier: 750 hours/month; note the DB resets on redeploy (use a PostgreSQL add-on for persistence).

### Option C — Koyeb
1. Push to GitHub
2. [koyeb.com](https://koyeb.com) → **Create App** → **GitHub** → pick repo
3. Set `BOT_TOKEN` env var
4. Koyeb auto-detects Dockerfile

---

## Persistent Database on Free Tiers

SQLite is fine for small bots. To avoid data loss on redeploy:

- **Railway**: attach a Volume at `/data` (free, persistent)
- **Render**: add a free **PostgreSQL** database and swap `database.py` for the PostgreSQL version (see below)
- **Koyeb**: use Koyeb's managed Postgres add-on

### Optional: PostgreSQL version
Replace `sqlite3` calls in `database.py` with `psycopg2`:
```python
import psycopg2, os
conn = psycopg2.connect(os.environ["DATABASE_URL"])
```
Then add `psycopg2-binary` to `requirements.txt`.

---

## Token Economics

| Action | Change |
|--------|--------|
| Deposit 1 ⭐ Star | +10 tokens |
| Win a game | +bet |
| Lose a game | −bet |
| Withdraw | ❌ Not possible |

Tokens have **zero real-world value** and cannot be withdrawn or converted back to Stars. This is intentional to comply with Telegram's Stars policy and keep the bot purely for entertainment.

---

## Responsible Gambling Notice

This bot is for entertainment only. Fun-tokens have no monetary value. Please gamble responsibly.
