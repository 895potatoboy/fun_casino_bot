# 🎰 Lucky Stars Casino Bot v2

A Telegram casino bot powered by Telegram Stars. Deposit Stars → get fun-tokens → gamble!

## Games

| Game | Rules | Max Win |
|------|-------|---------|
| 🎲 Dice | Roll 2 dice — 7/11 wins, 2/3/12 craps, else push | 1× |
| 🪙 Coin Flip | 50/50 heads or tails | 1× |
| 🎰 Slots | 3 reels — match symbols for prizes | 20× |
| 🃏 Blackjack | Beat the dealer, stand at 17 | 1× |
| 🎯 Roulette | Red/Black/Green/Even/Odd/Dozens | 14× |
| 🔢 Hi-Lo | Guess higher or lower, cash out anytime | Unlimited |
| 💣 Mines | 5×5 grid, 5 mines — find gems, cash out anytime | Unlimited |

## Setup

### 1. Create bot & enable Stars
1. Message [@BotFather](https://t.me/BotFather) on Telegram
2. `/newbot` → follow prompts → copy the token
3. `/mybots` → your bot → Bot Settings → Payments → scroll to bottom → ⭐ Telegram Stars → enable

### 2. Install & run on Raspberry Pi

```bash
# Transfer zip to Pi then:
unzip casino-bot.zip
cd casino-bot

# Create virtual environment
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Configure token
cp .env.example .env
nano .env   # paste your BOT_TOKEN

# Run
python3 bot.py
```

### 3. Run on boot (systemd)

```bash
sudo cp casino-bot.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable casino-bot
sudo systemctl start casino-bot

# Check status
sudo systemctl status casino-bot

# View logs
journalctl -u casino-bot -f
```

## Token Economics

| Action | Tokens |
|--------|--------|
| Deposit 1 ⭐ | +10 tokens |
| Win | +bet (or multiplied) |
| Lose | −bet |
| Withdraw | ❌ Never |

Fun-tokens have zero real-world value and cannot be withdrawn or refunded.
