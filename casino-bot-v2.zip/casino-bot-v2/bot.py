import os
import json
import random
import logging
from dotenv import load_dotenv

load_dotenv()  # loads .env automatically so no manual export needed

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, LabeledPrice
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    PreCheckoutQueryHandler, MessageHandler, filters,
    ContextTypes,
)
from database import Database

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

db = Database()

BOT_TOKEN       = os.environ["BOT_TOKEN"]
STARS_TO_TOKENS = 10
DEPOSIT_AMOUNTS = [1, 5, 10, 50, 100]
BET_SIZES       = [10, 25, 50, 100, 250, 500]

GAME_NAMES = {
    "dice":    "🎲 Dice",
    "coin":    "🪙 Coin Flip",
    "slots":   "🎰 Slots",
    "bj":      "🃏 Blackjack",
    "roulette":"🎯 Roulette",
    "hilo":    "🔢 Hi-Lo",
    "mines":   "💣 Mines",
}

# ── Keyboards ────────────────────────────────────────────────────────────────
def main_menu(user_id: int) -> InlineKeyboardMarkup:
    bal = db.get_balance(user_id)
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("💸 Deposit Stars", callback_data="deposit_menu")],
        [
            InlineKeyboardButton("🎲 Dice",        callback_data="game_dice"),
            InlineKeyboardButton("🪙 Coin Flip",   callback_data="game_coin"),
            InlineKeyboardButton("🎰 Slots",       callback_data="game_slots"),
        ],
        [
            InlineKeyboardButton("🃏 Blackjack",   callback_data="game_bj"),
            InlineKeyboardButton("🎯 Roulette",    callback_data="game_roulette"),
        ],
        [
            InlineKeyboardButton("🔢 Hi-Lo",       callback_data="game_hilo"),
            InlineKeyboardButton("💣 Mines",       callback_data="game_mines"),
        ],
        [InlineKeyboardButton(f"💰 Balance: {bal:,} tokens", callback_data="balance")],
        [InlineKeyboardButton("🏆 Leaderboard",    callback_data="leaderboard")],
    ])

def deposit_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        *[[InlineKeyboardButton(
            f"⭐ {s} Star{'s' if s > 1 else ''} → {s * STARS_TO_TOKENS:,} tokens",
            callback_data=f"buy_{s}",
        )] for s in DEPOSIT_AMOUNTS],
        [InlineKeyboardButton("🔙 Back", callback_data="main_menu")],
    ])

def bet_keyboard(game: str, user_id: int) -> InlineKeyboardMarkup:
    bal = db.get_balance(user_id)
    rows, row = [], []
    for b in BET_SIZES:
        label = f"{b:,}" if bal >= b else f"🚫{b:,}"
        row.append(InlineKeyboardButton(label, callback_data=f"bet_{game}_{b}"))
        if len(row) == 3:
            rows.append(row); row = []
    if row:
        rows.append(row)
    rows.append([InlineKeyboardButton("🔙 Back", callback_data="main_menu")])
    return InlineKeyboardMarkup(rows)

# ── Commands ─────────────────────────────────────────────────────────────────
async def cmd_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    db.ensure_user(user.id, user.first_name)
    await update.message.reply_text(
        f"👋 Welcome to *Lucky Stars Casino*, {user.first_name}!\n\n"
        "💫 Deposit Telegram Stars → get fun-tokens\n"
        "🎰 Use tokens to play 7 casino games\n"
        "⚠️ Tokens have no real value and cannot be withdrawn\n\n"
        "Choose an option below:",
        parse_mode="Markdown",
        reply_markup=main_menu(user.id),
    )

async def cmd_balance(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    db.ensure_user(user.id, user.first_name)
    bal = db.get_balance(user.id)
    await update.message.reply_text(
        f"💰 Your balance: *{bal:,} fun-tokens*",
        parse_mode="Markdown",
        reply_markup=main_menu(user.id),
    )

async def cmd_deposit(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    db.ensure_user(update.effective_user.id, update.effective_user.first_name)
    await update.message.reply_text(
        f"💸 *Deposit Telegram Stars*\n\nRate: 1 ⭐ = {STARS_TO_TOKENS} fun-tokens\n"
        "_Stars are non-refundable once converted_",
        parse_mode="Markdown",
        reply_markup=deposit_keyboard(),
    )

async def cmd_leaderboard(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    rows = db.leaderboard()
    medals = ["🥇","🥈","🥉"] + ["  "] * 7
    lines = ["🏆 *Top 10 Richest Players*\n"] + [
        f"{medals[i]} {name}: *{bal:,}* tokens"
        for i, (name, bal) in enumerate(rows)
    ]
    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")

# ── Payments ─────────────────────────────────────────────────────────────────
async def pre_checkout(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await update.pre_checkout_query.answer(ok=True)

async def successful_payment(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    user    = update.effective_user
    stars   = update.message.successful_payment.total_amount
    tokens  = stars * STARS_TO_TOKENS
    db.ensure_user(user.id, user.first_name)
    db.add_tokens(user.id, tokens)
    new_bal = db.get_balance(user.id)
    await update.message.reply_text(
        f"✅ *Payment received!*\n\n"
        f"⭐ {stars} Star{'s' if stars > 1 else ''} → *+{tokens:,} fun-tokens*\n"
        f"💰 New balance: *{new_bal:,} tokens*",
        parse_mode="Markdown",
        reply_markup=main_menu(user.id),
    )

# ── Callback router ───────────────────────────────────────────────────────────
async def button(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q    = update.callback_query
    data = q.data
    uid  = q.from_user.id
    db.ensure_user(uid, q.from_user.first_name)
    await q.answer()

    # ── Navigation ───────────────────────────────────────────────────────────
    if data == "main_menu":
        await q.edit_message_text(
            "🎰 *Lucky Stars Casino*",
            parse_mode="Markdown",
            reply_markup=main_menu(uid),
        )
        return

    if data == "balance":
        bal = db.get_balance(uid)
        await q.edit_message_text(
            f"💰 Your balance: *{bal:,} fun-tokens*",
            parse_mode="Markdown",
            reply_markup=main_menu(uid),
        )
        return

    if data == "leaderboard":
        rows = db.leaderboard()
        medals = ["🥇","🥈","🥉"] + ["  "] * 7
        lines = ["🏆 *Top 10 Richest Players*\n"] + [
            f"{medals[i]} {name}: *{bal:,}* tokens"
            for i, (name, bal) in enumerate(rows)
        ]
        await q.edit_message_text(
            "\n".join(lines),
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("🔙 Back", callback_data="main_menu")
            ]]),
        )
        return

    if data == "deposit_menu":
        await q.edit_message_text(
            f"💸 *Deposit Telegram Stars*\n\nRate: 1 ⭐ = {STARS_TO_TOKENS} fun-tokens\n"
            "_Stars are non-refundable once converted_",
            parse_mode="Markdown",
            reply_markup=deposit_keyboard(),
        )
        return

    # ── Buy Stars invoice ─────────────────────────────────────────────────────
    if data.startswith("buy_"):
        stars = int(data.split("_")[1])
        tokens = stars * STARS_TO_TOKENS
        await ctx.bot.send_invoice(
            chat_id=uid,
            title=f"⭐ {stars} Star{'s' if stars > 1 else ''}",
            description=f"Converts to {tokens:,} fun-tokens for casino games. Non-withdrawable.",
            payload=f"deposit_{stars}",
            currency="XTR",
            prices=[LabeledPrice(label=f"{tokens:,} Fun-Tokens", amount=stars)],
        )
        return

    # ── Game entry ────────────────────────────────────────────────────────────
    if data.startswith("game_"):
        game = data.split("_", 1)[1]
        # Roulette has its own bet menu
        if game == "roulette":
            await _roulette_menu(q, uid)
            return
        bal = db.get_balance(uid)
        await q.edit_message_text(
            f"{GAME_NAMES[game]}\n\nBalance: *{bal:,}* tokens\nChoose your bet:",
            parse_mode="Markdown",
            reply_markup=bet_keyboard(game, uid),
        )
        return

    # ── Bet placed ────────────────────────────────────────────────────────────
    if data.startswith("bet_"):
        parts = data.split("_")
        game  = parts[1]
        bet   = int(parts[2])
        bal   = db.get_balance(uid)
        if bal < bet:
            await q.edit_message_text(
                f"❌ Not enough tokens!\nBalance: *{bal:,}* — Bet: *{bet:,}*",
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("💸 Deposit Stars", callback_data="deposit_menu")],
                    [InlineKeyboardButton("🔙 Back",          callback_data="main_menu")],
                ]),
            )
            return
        if game == "hilo":
            await _hilo_start(q, uid, bet)
        elif game == "mines":
            await _mines_start(q, uid, bet)
        else:
            await _play_simple(q, uid, game, bet)
        return

    # ── Roulette bet type ─────────────────────────────────────────────────────
    if data.startswith("rou_"):
        await _roulette_handle(q, uid, data)
        return

    # ── Hi-Lo actions ─────────────────────────────────────────────────────────
    if data.startswith("hilo_"):
        await _hilo_handle(q, uid, data)
        return

    # ── Mines actions ─────────────────────────────────────────────────────────
    if data.startswith("mine_"):
        await _mines_handle(q, uid, data)
        return

# ── Simple games ──────────────────────────────────────────────────────────────
async def _play_simple(q, uid: int, game: str, bet: int):
    if game == "dice":    result, delta, detail = _game_dice(bet)
    elif game == "coin":  result, delta, detail = _game_coin(bet)
    elif game == "slots": result, delta, detail = _game_slots(bet)
    elif game == "bj":    result, delta, detail = _game_bj(bet)
    else: return

    db.update_balance(uid, delta)
    new_bal = db.get_balance(uid)
    outcome = "🎉 *WIN!*" if delta > 0 else ("💔 *LOSS*" if delta < 0 else "🤝 *PUSH*")
    sign    = "+" if delta >= 0 else ""

    await q.edit_message_text(
        f"{GAME_NAMES[game]}\n\n{detail}\n\n"
        f"{outcome}  {sign}{delta:,} tokens\n"
        f"💰 Balance: *{new_bal:,}* tokens",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🔄 Play Again", callback_data=f"game_{game}")],
            [InlineKeyboardButton("🏠 Main Menu",  callback_data="main_menu")],
        ]),
    )

# ── Dice ──────────────────────────────────────────────────────────────────────
def _game_dice(bet):
    d1, d2 = random.randint(1,6), random.randint(1,6)
    s = d1 + d2
    faces = ["⚀","⚁","⚂","⚃","⚄","⚅"]
    detail = f"{faces[d1-1]} + {faces[d2-1]} = *{s}*"
    if s in (7, 11):    return "win",  bet,  detail + "\nNatural! 🎉"
    if s in (2, 3, 12): return "loss", -bet, detail + "\nCraps! 💀"
    return "push", 0, detail + "\nPush — no change."

# ── Coin ──────────────────────────────────────────────────────────────────────
def _game_coin(bet):
    win  = random.random() < 0.5
    side = "Heads 🪙" if win else "Tails 🔵"
    call = "Heads 🪙" if win else "Tails 🔵"
    return ("win", bet, f"Landed: *{side}*\nYour call: *{call}* ✅") if win \
        else ("loss", -bet, f"Landed: *{'Tails 🔵' if win else 'Heads 🪙' }*\nYour call: *{call}* ❌")

# ── Slots ─────────────────────────────────────────────────────────────────────
SLOT_REELS = ["🍒","🍋","🔔","⭐","💎","7️⃣","🍀"]
SLOT_PAYS  = {"💎":20,"7️⃣":15,"⭐":10,"🍀":8,"🔔":5,"🍋":3,"🍒":2}

def _game_slots(bet):
    r = [random.choice(SLOT_REELS) for _ in range(3)]
    line = f"[ {r[0]} | {r[1]} | {r[2]} ]"
    if r[0] == r[1] == r[2]:
        m = SLOT_PAYS[r[0]]
        return "win", bet * m, f"{line}\n🎰 JACKPOT ×{m}!"
    if r[0] == r[1] or r[1] == r[2]:
        return "win", bet, f"{line}\nTwo of a kind — 1× win!"
    return "loss", -bet, f"{line}\nNo match."

# ── Blackjack ─────────────────────────────────────────────────────────────────
def _card():
    rank = random.choice(["A","2","3","4","5","6","7","8","9","10","J","Q","K"])
    suit = random.choice(["♠","♥","♦","♣"])
    val  = 11 if rank == "A" else (10 if rank in ("J","Q","K") else int(rank))
    return rank + suit, val

def _hand_val(hand):
    total = sum(v for _,v in hand)
    aces  = sum(1 for r,_ in hand if r[0] == "A")
    while total > 21 and aces:
        total -= 10; aces -= 1
    return total

def _game_bj(bet):
    player = [_card(), _card()]
    dealer = [_card(), _card()]
    while _hand_val(player) < 17: player.append(_card())
    while _hand_val(dealer) < 17: dealer.append(_card())
    pv, dv = _hand_val(player), _hand_val(dealer)
    ph = " ".join(c for c,_ in player)
    dh = " ".join(c for c,_ in dealer)
    detail = f"You:    {ph} = *{pv}*\nDealer: {dh} = *{dv}*"
    if pv > 21: return "loss", -bet, detail + "\nBust! 💥"
    if dv > 21: return "win",  bet,  detail + "\nDealer busts! 🎉"
    if pv > dv: return "win",  bet,  detail
    if pv < dv: return "loss", -bet, detail
    return "push", 0, detail + "\nPush!"

# ── Roulette ──────────────────────────────────────────────────────────────────
ROULETTE_RED = {1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36}

async def _roulette_menu(q, uid: int):
    bal = db.get_balance(uid)
    await q.edit_message_text(
        f"🎯 *Roulette*\n\nBalance: *{bal:,}* tokens\n\nChoose your bet type:",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup([
            [
                InlineKeyboardButton("🔴 Red (2×)",    callback_data="rou_type_red"),
                InlineKeyboardButton("⚫ Black (2×)",  callback_data="rou_type_black"),
            ],
            [
                InlineKeyboardButton("🟢 Green/0 (14×)", callback_data="rou_type_green"),
            ],
            [
                InlineKeyboardButton("📊 Even (2×)",   callback_data="rou_type_even"),
                InlineKeyboardButton("📊 Odd (2×)",    callback_data="rou_type_odd"),
            ],
            [
                InlineKeyboardButton("1–12 (3×)",      callback_data="rou_type_low"),
                InlineKeyboardButton("13–24 (3×)",     callback_data="rou_type_mid"),
                InlineKeyboardButton("25–36 (3×)",     callback_data="rou_type_high"),
            ],
            [InlineKeyboardButton("🔙 Back", callback_data="main_menu")],
        ]),
    )

async def _roulette_handle(q, uid: int, data: str):
    parts = data.split("_")
    # rou_type_<kind>  or  rou_bet_<kind>_<amount>
    if parts[1] == "type":
        kind = parts[2]
        bal  = db.get_balance(uid)
        rows, row = [], []
        for b in BET_SIZES:
            label = f"{b:,}" if bal >= b else f"🚫{b:,}"
            row.append(InlineKeyboardButton(label, callback_data=f"rou_bet_{kind}_{b}"))
            if len(row) == 3:
                rows.append(row); row = []
        if row: rows.append(row)
        rows.append([InlineKeyboardButton("🔙 Back", callback_data="game_roulette")])
        await q.edit_message_text(
            f"🎯 *Roulette — {kind.title()}*\n\nBalance: *{bal:,}* tokens\nChoose bet:",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup(rows),
        )
        return

    if parts[1] == "bet":
        kind   = parts[2]
        bet    = int(parts[3])
        bal    = db.get_balance(uid)
        if bal < bet:
            await q.edit_message_text(
                f"❌ Not enough tokens! Balance: *{bal:,}*",
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("🔙 Back", callback_data="main_menu")
                ]]),
            )
            return

        num  = random.randint(0, 36)
        col  = "🟢" if num == 0 else ("🔴" if num in ROULETTE_RED else "⚫")
        even = num > 0 and num % 2 == 0

        wins = {
            "red":   num in ROULETTE_RED,
            "black": num != 0 and num not in ROULETTE_RED,
            "green": num == 0,
            "even":  even,
            "odd":   num > 0 and not even,
            "low":   1  <= num <= 12,
            "mid":   13 <= num <= 24,
            "high":  25 <= num <= 36,
        }
        mult = {"red":2,"black":2,"green":14,"even":2,"odd":2,"low":3,"mid":3,"high":3}

        won   = wins[kind]
        delta = bet * (mult[kind] - 1) if won else -bet
        db.update_balance(uid, delta)
        new_bal = db.get_balance(uid)
        outcome = "🎉 *WIN!*" if won else "💔 *LOSS*"
        sign    = "+" if delta >= 0 else ""

        await q.edit_message_text(
            f"🎯 *Roulette*\n\n"
            f"Ball landed on: {col} *{num}*\n"
            f"Your bet: *{kind.title()}*\n\n"
            f"{outcome}  {sign}{delta:,} tokens\n"
            f"💰 Balance: *{new_bal:,}* tokens",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔄 Play Again", callback_data="game_roulette")],
                [InlineKeyboardButton("🏠 Main Menu",  callback_data="main_menu")],
            ]),
        )

# ── Hi-Lo ─────────────────────────────────────────────────────────────────────
def _hilo_multiplier(streak: int) -> float:
    return round(1.5 + streak * 0.5, 1)

async def _hilo_start(q, uid: int, bet: int):
    db.update_balance(uid, -bet)
    current = random.randint(1, 13)
    db.hilo_start(uid, current, bet)
    await _hilo_show(q, uid, current, bet, bet, 0, first=True)

async def _hilo_show(q, uid, current, bet, pot, streak, first=False, msg=""):
    card_name = ["A","2","3","4","5","6","7","8","9","10","J","Q","K"][current - 1]
    mult      = _hilo_multiplier(streak)
    bal       = db.get_balance(uid)
    text = (
        f"🔢 *Hi-Lo*\n\n"
        f"{'Started! ' if first else ''}"
        f"{msg}\n" if msg else ""
        f"Current card: *{card_name}*\n"
        f"Streak: *{streak}* 🔥\n"
        f"Next win multiplier: *{mult}×*\n"
        f"Pot: *{pot:,}* tokens\n"
        f"💰 Balance: *{bal:,}* tokens\n\n"
        f"Will the next card be higher or lower?"
    )
    await q.edit_message_text(
        text,
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup([
            [
                InlineKeyboardButton("⬆️ Higher", callback_data="hilo_high"),
                InlineKeyboardButton("⬇️ Lower",  callback_data="hilo_low"),
            ],
            [InlineKeyboardButton("💰 Cash Out",   callback_data="hilo_cashout")],
            [InlineKeyboardButton("🏠 Main Menu",  callback_data="hilo_quit")],
        ]),
    )

async def _hilo_handle(q, uid: int, data: str):
    action = data.split("_")[1]
    row    = db.hilo_get(uid)
    if not row:
        await q.edit_message_text("No active Hi-Lo game.", reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton("🏠 Main Menu", callback_data="main_menu")
        ]]))
        return

    current, pot, bet, streak = row

    if action == "cashout":
        db.update_balance(uid, pot)
        db.hilo_clear(uid)
        new_bal = db.get_balance(uid)
        await q.edit_message_text(
            f"🔢 *Hi-Lo — Cashed Out!*\n\n"
            f"💰 Won: *+{pot:,}* tokens\n"
            f"Balance: *{new_bal:,}* tokens",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔄 Play Again", callback_data="game_hilo")],
                [InlineKeyboardButton("🏠 Main Menu",  callback_data="main_menu")],
            ]),
        )
        return

    if action == "quit":
        db.hilo_clear(uid)
        await q.edit_message_text(
            "🔢 *Hi-Lo* — game abandoned.",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("🏠 Main Menu", callback_data="main_menu")
            ]]),
        )
        return

    next_card = random.randint(1, 13)
    card_names = ["A","2","3","4","5","6","7","8","9","10","J","Q","K"]
    curr_name = card_names[current - 1]
    next_name = card_names[next_card - 1]

    correct = (action == "high" and next_card > current) or \
              (action == "low"  and next_card < current)
    tie     = next_card == current

    if tie:
        # Tie = push, keep going with new card
        db.hilo_update(uid, next_card, pot, streak)
        await _hilo_show(q, uid, next_card, bet, pot, streak,
                         msg=f"*{curr_name}* → *{next_name}* — Tie! No change.")
        return

    if correct:
        mult    = _hilo_multiplier(streak)
        new_pot = int(pot * mult)
        streak += 1
        db.hilo_update(uid, next_card, new_pot, streak)
        await _hilo_show(q, uid, next_card, bet, new_pot, streak,
                         msg=f"*{curr_name}* → *{next_name}* ✅ +{mult}× pot!")
    else:
        db.hilo_clear(uid)
        new_bal = db.get_balance(uid)
        await q.edit_message_text(
            f"🔢 *Hi-Lo*\n\n"
            f"*{curr_name}* → *{next_name}* ❌ Wrong!\n\n"
            f"💔 *LOSS* — lost *{bet:,}* tokens\n"
            f"💰 Balance: *{new_bal:,}* tokens",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔄 Play Again", callback_data="game_hilo")],
                [InlineKeyboardButton("🏠 Main Menu",  callback_data="main_menu")],
            ]),
        )

# ── Mines ─────────────────────────────────────────────────────────────────────
MINES_SIZE  = 5   # 5×5 grid
MINES_COUNT = 5   # number of mines

def _mines_multiplier(revealed: int) -> float:
    # More gems = higher multiplier
    return round(1.0 + revealed * 0.4, 1)

def _make_mines_board():
    cells = list(range(MINES_SIZE * MINES_SIZE))
    mines = set(random.sample(cells, MINES_COUNT))
    return list(mines)

def _mines_grid_keyboard(uid: int, revealed_list: list, alive: bool, show_all=False):
    row_btns = []
    session = db.mines_get(uid)
    if not session:
        return InlineKeyboardMarkup([[InlineKeyboardButton("🏠 Main Menu", callback_data="main_menu")]])
    mines_list = json.loads(session[0])
    mines_set  = set(mines_list)

    for r in range(MINES_SIZE):
        row = []
        for c in range(MINES_SIZE):
            idx = r * MINES_SIZE + c
            if idx in revealed_list:
                row.append(InlineKeyboardButton("💎", callback_data="mine_noop"))
            elif show_all:
                row.append(InlineKeyboardButton(
                    "💣" if idx in mines_set else "·",
                    callback_data="mine_noop"
                ))
            elif not alive:
                row.append(InlineKeyboardButton(
                    "💣" if idx in mines_set else "·",
                    callback_data="mine_noop"
                ))
            else:
                row.append(InlineKeyboardButton("⬜", callback_data=f"mine_reveal_{idx}"))
        row_btns.append(row)

    if alive:
        row_btns.append([InlineKeyboardButton("💰 Cash Out", callback_data="mine_cashout")])
    row_btns.append([InlineKeyboardButton("🏠 Main Menu", callback_data="main_menu")])
    return InlineKeyboardMarkup(row_btns)

async def _mines_start(q, uid: int, bet: int):
    db.update_balance(uid, -bet)
    board    = _make_mines_board()
    db.mines_start(uid, json.dumps(board), bet)
    bal      = db.get_balance(uid)
    await q.edit_message_text(
        f"💣 *Mines*\n\n"
        f"Grid: {MINES_SIZE}×{MINES_SIZE} — {MINES_COUNT} mines hidden\n"
        f"Bet: *{bet:,}* tokens\n"
        f"💰 Balance: *{bal:,}* tokens\n\n"
        f"Tap squares to reveal 💎 gems — avoid 💣 mines!\n"
        f"Cash out anytime to keep your winnings.",
        parse_mode="Markdown",
        reply_markup=_mines_grid_keyboard(uid, [], True),
    )

async def _mines_handle(q, uid: int, data: str):
    parts  = data.split("_")
    action = parts[1]

    if action == "noop":
        return

    session = db.mines_get(uid)
    if not session:
        await q.edit_message_text("No active Mines game.", reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton("🏠 Main Menu", callback_data="main_menu")
        ]]))
        return

    board_json, revealed_json, bet, pot, alive = session
    mines_set  = set(json.loads(board_json))
    revealed   = json.loads(revealed_json)

    if action == "cashout":
        db.update_balance(uid, pot)
        db.mines_clear(uid)
        new_bal = db.get_balance(uid)
        await q.edit_message_text(
            f"💣 *Mines — Cashed Out!*\n\n"
            f"Gems found: *{len(revealed)}* 💎\n"
            f"💰 Won: *+{pot:,}* tokens\n"
            f"Balance: *{new_bal:,}* tokens",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔄 Play Again", callback_data="game_mines")],
                [InlineKeyboardButton("🏠 Main Menu",  callback_data="main_menu")],
            ]),
        )
        return

    if action == "reveal":
        idx = int(parts[2])
        if idx in mines_set:
            # Hit a mine!
            db.mines_update(uid, revealed_json, 0, 0)
            db.mines_clear(uid)
            new_bal = db.get_balance(uid)
            await q.edit_message_text(
                f"💣 *BOOM! You hit a mine!*\n\n"
                f"Gems found before: *{len(revealed)}* 💎\n"
                f"💔 Lost: *{bet:,}* tokens\n"
                f"💰 Balance: *{new_bal:,}* tokens",
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔄 Play Again", callback_data="game_mines")],
                    [InlineKeyboardButton("🏠 Main Menu",  callback_data="main_menu")],
                ]),
            )
            return

        # Safe tile — gem found!
        revealed.append(idx)
        mult    = _mines_multiplier(len(revealed))
        new_pot = int(bet * mult)
        db.mines_update(uid, json.dumps(revealed), new_pot, 1)
        bal     = db.get_balance(uid)
        await q.edit_message_text(
            f"💣 *Mines*\n\n"
            f"💎 Gem found! ({len(revealed)} total)\n"
            f"Multiplier: *{mult}×*\n"
            f"Cash out value: *{new_pot:,}* tokens\n"
            f"💰 Balance: *{bal:,}* tokens\n\n"
            f"Keep going or cash out?",
            parse_mode="Markdown",
            reply_markup=_mines_grid_keyboard(uid, revealed, True),
        )

# ── Main ──────────────────────────────────────────────────────────────────────
def main():
    app = Application.builder().token(BOT_TOKEN).build()

    app.add_handler(CommandHandler("start",       cmd_start))
    app.add_handler(CommandHandler("balance",     cmd_balance))
    app.add_handler(CommandHandler("deposit",     cmd_deposit))
    app.add_handler(CommandHandler("leaderboard", cmd_leaderboard))
    app.add_handler(CallbackQueryHandler(button))
    app.add_handler(PreCheckoutQueryHandler(pre_checkout))
    app.add_handler(MessageHandler(filters.SUCCESSFUL_PAYMENT, successful_payment))

    logger.info("🎰 Lucky Stars Casino Bot started!")
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
