import sqlite3
import os

DB_PATH = os.environ.get("DB_PATH", "casino.db")

class Database:
    def __init__(self):
        self.conn = sqlite3.connect(DB_PATH, check_same_thread=False)
        self._create_tables()

    def _create_tables(self):
        self.conn.executescript("""
            CREATE TABLE IF NOT EXISTS users (
                user_id    INTEGER PRIMARY KEY,
                name       TEXT    NOT NULL,
                balance    INTEGER NOT NULL DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS transactions (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id    INTEGER NOT NULL,
                type       TEXT    NOT NULL,
                amount     INTEGER NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS hilo_sessions (
                user_id    INTEGER PRIMARY KEY,
                current    INTEGER NOT NULL,
                pot        INTEGER NOT NULL,
                bet        INTEGER NOT NULL,
                streak     INTEGER NOT NULL DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS mines_sessions (
                user_id    INTEGER PRIMARY KEY,
                board      TEXT    NOT NULL,
                revealed   TEXT    NOT NULL DEFAULT '[]',
                bet        INTEGER NOT NULL,
                pot        INTEGER NOT NULL,
                alive      INTEGER NOT NULL DEFAULT 1
            );
        """)
        self.conn.commit()

    def ensure_user(self, user_id: int, name: str):
        self.conn.execute(
            "INSERT OR IGNORE INTO users (user_id, name) VALUES (?, ?)",
            (user_id, name),
        )
        self.conn.commit()

    def get_balance(self, user_id: int) -> int:
        row = self.conn.execute(
            "SELECT balance FROM users WHERE user_id = ?", (user_id,)
        ).fetchone()
        return row[0] if row else 0

    def add_tokens(self, user_id: int, amount: int):
        self.conn.execute(
            "UPDATE users SET balance = balance + ? WHERE user_id = ?",
            (amount, user_id),
        )
        self.conn.execute(
            "INSERT INTO transactions (user_id, type, amount) VALUES (?, 'deposit', ?)",
            (user_id, amount),
        )
        self.conn.commit()

    def update_balance(self, user_id: int, delta: int):
        self.conn.execute(
            "UPDATE users SET balance = MAX(0, balance + ?) WHERE user_id = ?",
            (delta, user_id),
        )
        t = "win" if delta > 0 else ("loss" if delta < 0 else "push")
        self.conn.execute(
            "INSERT INTO transactions (user_id, type, amount) VALUES (?, ?, ?)",
            (user_id, t, abs(delta)),
        )
        self.conn.commit()

    def leaderboard(self, limit: int = 10):
        return self.conn.execute(
            "SELECT name, balance FROM users ORDER BY balance DESC LIMIT ?", (limit,)
        ).fetchall()

    # ── Hi-Lo session ────────────────────────────────────────────────────────
    def hilo_start(self, user_id: int, current: int, bet: int):
        self.conn.execute("""
            INSERT OR REPLACE INTO hilo_sessions (user_id, current, pot, bet, streak)
            VALUES (?, ?, ?, ?, 0)
        """, (user_id, current, bet, bet))
        self.conn.commit()

    def hilo_get(self, user_id: int):
        return self.conn.execute(
            "SELECT current, pot, bet, streak FROM hilo_sessions WHERE user_id = ?",
            (user_id,)
        ).fetchone()

    def hilo_update(self, user_id: int, current: int, pot: int, streak: int):
        self.conn.execute(
            "UPDATE hilo_sessions SET current=?, pot=?, streak=? WHERE user_id=?",
            (current, pot, streak, user_id)
        )
        self.conn.commit()

    def hilo_clear(self, user_id: int):
        self.conn.execute("DELETE FROM hilo_sessions WHERE user_id=?", (user_id,))
        self.conn.commit()

    # ── Mines session ────────────────────────────────────────────────────────
    def mines_start(self, user_id: int, board: str, bet: int):
        self.conn.execute("""
            INSERT OR REPLACE INTO mines_sessions (user_id, board, revealed, bet, pot, alive)
            VALUES (?, ?, '[]', ?, ?, 1)
        """, (user_id, board, bet, bet))
        self.conn.commit()

    def mines_get(self, user_id: int):
        return self.conn.execute(
            "SELECT board, revealed, bet, pot, alive FROM mines_sessions WHERE user_id=?",
            (user_id,)
        ).fetchone()

    def mines_update(self, user_id: int, revealed: str, pot: int, alive: int):
        self.conn.execute(
            "UPDATE mines_sessions SET revealed=?, pot=?, alive=? WHERE user_id=?",
            (revealed, pot, alive, user_id)
        )
        self.conn.commit()

    def mines_clear(self, user_id: int):
        self.conn.execute("DELETE FROM mines_sessions WHERE user_id=?", (user_id,))
        self.conn.commit()
